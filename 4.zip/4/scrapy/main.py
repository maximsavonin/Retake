from bs4 import BeautifulSoup
import requests
import sqlite3

url = 'https://goldapple.ru/aptechnaja-kosmetika'

connection = sqlite3.connect('my_database.db')
cursor = connection.cursor()

# Создаем таблицу Users
cursor.execute('''
CREATE TABLE IF NOT EXISTS Product (
id INTEGER PRIMARY KEY,
Company TEXT NOT NULL,
Name TEXT NOT NULL,
Price INTEGER
)
''')

cursor.execute('DELETE FROM Product WHERE id > 0')

connection.commit()

for p in range(1, 20):
    u = url + '?p=' + str(p)
    page = requests.get(u)
    soup = BeautifulSoup(page.text, 'html.parser')

    list_name1 = soup.findAll('meta', itemprop='name')
    list_price1 = soup.findAll('meta', itemprop='price')

    i = 0
    j = 0
    list_company = []
    list_name = []
    list_price = []
    while i+1 < len(list_name1):
        if not("Золотое яблоко" in list_name1[i+1]['content'] or "Золотое яблоко" in list_name1[i]['content']):
            list_company.append(list_name1[i]['content'])
            list_name.append(list_name1[i+1]['content'])
        i += 2

    for i in range(len(list_price1)):
        if list_price1[i]['content'] != '0':
            list_price.append(list_price1[i]['content'])

    print(list_price)

    i = 0
    while i < len(list_company) and i < len(list_price) and i < len(list_name):
        cursor.execute('INSERT INTO Product (Company, Name, Price) VALUES (?, ?, ?)', (list_company[i], list_name[i], int(list_price[i])))
        i += 1

    cursor.execute('SELECT * FROM Product')
    products = cursor.fetchall()

    # Сохраняем изменения и закрываем соединение
    connection.commit()

cursor.execute('SELECT * FROM Product')
products = cursor.fetchall()

# Выводим результаты
for i in products:
  print(i)

# Сохраняем изменения и закрываем соединение
connection.commit()
connection.close()