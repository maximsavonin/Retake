from flask import request, render_template, Flask

app = Flask(__name__)

@app.route('/', methods=['GET'])
def main():
    age = request.args.get('ageInput')
    availability = request.args.get('availabilityCheckbox')
    sort_type = request.args.get('sortType')
    return render_template("base.html", books=[0]), 200

if __name__ == '__main__':
       app.run(host='0.0.0.0', port=30006, debug=True)