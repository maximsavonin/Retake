from sqlalchemy import desc
import flask_sqlalchemy

db = flask_sqlalchemy.SQLAlchemy()


class Product(db.Model):
    __tablename__ = 'produsct'
    ID = db.Column(db.BigInteger, primary_key=True)
    company = db.Column(db.String(50))
    name = db.Column(db.String(50))
    price = db.Column(db.Integer)

def get_all_filtered(model,comp=None, sort_type=None):
    data = model.query

    if comp:
        data = data.filter(model.company == comp)

    if sort_type == "1":

    elif sort_type == "2":
        pass
    elif sort_type == "3":
        pass
    elif sort_type == "4":
        pass
    elif sort_type == "5":
        pass
    elif sort_type == "6":
        pass

    return data

def get_all(model):
    data = model.query.all()
    return data


def add_instance(model, **kwargs):
    instance = model(**kwargs)
    db.session.add(instance)
    commit_changes()


def delete_instance(model, id):
    model.query.filter_by(id=id).delete()
    commit_changes()


def edit_instance(model, id, **kwargs):
    instance = model.query.filter_by(id=id).all()[0]
    for attr, new_value in kwargs.items():
        setattr(instance, attr, new_value)
    commit_changes()


def commit_changes():
    db.session.commit()
